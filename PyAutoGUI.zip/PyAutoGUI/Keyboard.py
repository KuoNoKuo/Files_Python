import pyautogui as _

_.typewrite("hello world!", interval = 0.001)



